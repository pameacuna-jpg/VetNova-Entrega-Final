package com.vetnova.inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
